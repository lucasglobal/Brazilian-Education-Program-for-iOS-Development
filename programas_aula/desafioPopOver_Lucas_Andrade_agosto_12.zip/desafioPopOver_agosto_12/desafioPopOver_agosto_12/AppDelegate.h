//
//  AppDelegate.h
//  desafioPopOver_agosto_12
//
//  Created by Lucas Andrade on 8/12/14.
//  Copyright (c) 2014 LucasAndradeRibeiro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
