//
//  AppDelegate.h
//  exemplo1TableView_julho_15
//
//  Created by Lucas Andrade on 7/15/14.
//  Copyright (c) 2014 LucasAndradeRibeiro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,NSCoding>

@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic) NSMutableArray* numeros;

@end
