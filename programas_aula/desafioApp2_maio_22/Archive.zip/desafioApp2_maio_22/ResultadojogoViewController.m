//
//  ResultadojogoViewController.m
//  desafioApp2_maio_22
//
//  Created by LucasAndrade on 5/22/14.
//  Copyright (c) 2014 Lucas Andrade Ribeiro. All rights reserved.
//

#import "ResultadojogoViewController.h"

@interface ResultadojogoViewController ()

@end

@implementation ResultadojogoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (id)initWithNumero:(int) numero Tipo:(int) tipo
{
  
        [self setNumero:numero];
        [self setTipo:tipo];
        
    
    return self;
}

- (void)viewDidLoad
{
    if(self.numero == 0){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoUm.jpg"]];
        pessoa.frame = CGRectMake(110,110, 90, 100);
        [self.view addSubview:pessoa];
    }
    if(self.numero == 1){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoDois.jpg"]];
        pessoa.frame = CGRectMake(110,110, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(self.numero == 2){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoTres.jpg"]];
        pessoa.frame = CGRectMake(110,110, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(self.numero == 3){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoQuatro.jpg"]];
        pessoa.frame = CGRectMake(110,110, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(self.numero == 4){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoCinco.jpg"]];
        pessoa.frame = CGRectMake(110,110, 90, 100);
        [self.view addSubview:pessoa];
        
    }


    
    

    if(self.tipo == 0){
        self.labelTipoVoce.text = @"PAR";
    }
    else{
        self.labelTipoVoce.text = @"ÍMPAR";
    }
    
    int randNumeroPC = (arc4random() % (5 - 1 + 1)) + 1;
    if([self.labelTipoVoce.text isEqualToString:@"PAR"]){
        self.labelTipoPC.text = @"ÍMPAR";
    }
    else{
        self.labelTipoPC.text = @"PAR";
    }
    
    
    if(randNumeroPC == 1){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoUm.jpg"]];
        pessoa.frame = CGRectMake(110,410, 90, 100);
        [self.view addSubview:pessoa];
    }
    if(randNumeroPC == 2){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoDois.jpg"]];
        pessoa.frame = CGRectMake(110,410, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(randNumeroPC== 3){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoTres.jpg"]];
        pessoa.frame = CGRectMake(110,410, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(randNumeroPC== 4){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoQuatro.jpg"]];
        pessoa.frame = CGRectMake(110,410, 90, 100);
        [self.view addSubview:pessoa];
        
    }
    if(randNumeroPC == 5){
        UIImageView* pessoa = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dedoCinco.jpg"]];
        pessoa.frame = CGRectMake(110,410, 90, 100);
        [self.view addSubview:pessoa];
        
    }

    
    
    if((((self.numero) + 1) + randNumeroPC)%2 == 0){
        if([self.labelTipoVoce.text isEqualToString: @"PAR"]){
          self.labelResultado.text = [[NSString alloc]initWithFormat:@"GANHOU! DEU PAR, DEU %d",(((self.numero) + 1) + randNumeroPC)];
            self.labelResultado.textColor = [UIColor greenColor];
        }
        else{
            self.labelResultado.text = [[NSString alloc]initWithFormat:@"PERDEU! DEU PAR, DEU %d",(((self.numero) + 1) + randNumeroPC)];
            self.labelResultado.textColor = [UIColor redColor];
        }
    }
    else{
        if([self.labelTipoVoce.text isEqualToString: @"ÍMPAR"]){
            self.labelResultado.text = [[NSString alloc]initWithFormat:@"GANHOU! DEU ÍMPAR, DEU %d",(((self.numero) + 1) + randNumeroPC)];
            self.labelResultado.textColor = [UIColor greenColor];
        }
        else{
            self.labelResultado.text = [[NSString alloc]initWithFormat:@"PERDEU! DEU ÍMPAR, DEU %d",(((self.numero) + 1) + randNumeroPC)];
            self.labelResultado.textColor = [UIColor redColor];
        }
    }
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)botaoJogarNovamente:(id)sender {

[self dismissViewControllerAnimated:YES completion:nil];
}
@end
