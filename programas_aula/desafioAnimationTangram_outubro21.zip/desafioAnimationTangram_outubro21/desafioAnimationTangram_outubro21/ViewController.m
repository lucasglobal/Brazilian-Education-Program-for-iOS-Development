//
//  ViewController.m
//  desafioAnimationTangram_outubro21
//
//  Created by Lucas Andrade on 10/21/14.
//  Copyright (c) 2014 LucasAndradeRibeiro. All rights reserved.
//

#import "ViewController.h"
#import "Triangle.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGRect rect = CGRectMake(50, 50, 50, 100);
    Triangle* triangulo = [[Triangle alloc]initWithFrame:rect];
    triangulo.backgroundColor = [UIColor clearColor];
    [self.view addSubview:triangulo];
    
    triangulo.transform = CGAffineTransformMakeRotation(45*M_PI/180);
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
